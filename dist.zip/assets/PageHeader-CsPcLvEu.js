import{j as e}from"./index-BUKIunod.js";import{B as r}from"./Banner-BOxJP7CD.js";function n(t){return e.jsx(r,{...t,subtitle:t.blurb??t.subtitle})}export{n as P};
