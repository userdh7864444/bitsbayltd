import{j as e}from"./index-wwPfcjSI.js";import{B as r}from"./Banner-CBupUEhy.js";function n(t){return e.jsx(r,{...t,subtitle:t.blurb??t.subtitle})}export{n as P};
