import{j as e}from"./index-gOwFw-L5.js";import{B as r}from"./Banner-B3n2ehQ5.js";function n(t){return e.jsx(r,{...t,subtitle:t.blurb??t.subtitle})}export{n as P};
